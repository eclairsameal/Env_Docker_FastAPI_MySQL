# FastAPI project

docker-compose up -d
